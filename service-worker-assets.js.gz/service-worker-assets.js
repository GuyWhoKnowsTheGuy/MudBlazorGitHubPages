self.assetsManifest = {
  "version": "6Hs1JKKq",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-3FM/mjas9rQiq2CY+FQPy1Pe1iCLSx/qZltQxK4dcuQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Qf9/gSPxTxchB08Wi5WXxjPqw2IQvnyVUW27s7cwoUo=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-4qCjCkeMkrC39fhhzGK6jZVM+CSQXhBgirZfr1DM/6I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yv2qi7o6jg.wasm"
    },
    {
      "hash": "sha256-+5+/1obWKmNeB9zuGBeA2beO5qKtdJKqtqHxaoMFDzE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.fj8j66h5p2.wasm"
    },
    {
      "hash": "sha256-TcOopK2q4BGmAVHWFJKGowX6MdOKubrM35AeS7HibLg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.34a2hn3s9q.wasm"
    },
    {
      "hash": "sha256-Ja3gzCUHbkYBsXKGg2ox5w/N19E826pHlMocqbQx96o=",
      "url": "_framework/Microsoft.AspNetCore.Components.htc1qfgzig.wasm"
    },
    {
      "hash": "sha256-wPQePOM2M0BrqToV8H6UgyPZs4MfkZPkm3oBAAO94jc=",
      "url": "_framework/Microsoft.Extensions.Configuration.0c1wqrwaiz.wasm"
    },
    {
      "hash": "sha256-ksLoEz6z924BYV/406a8QZfBF562Auo+OyLZsx377cM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.qewezpykee.wasm"
    },
    {
      "hash": "sha256-pDTl0fevy0i6hlfWPKhPeAcEOtGIXkx4yhbQIxDOiPM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.c0lsqeepwk.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-VerCbY+gtR4pfthf2m0i5NHYHdzae5bPti0u8jro/mE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.pzhxlzbjs7.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-63CoZs2v8kUdc0XLRhWY4gt+HvG+sALt8MhboCYTjp0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bkdtnkwhhv.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-aGKgw+oy/q1c/wB6pq6Jwqo6y8C6P1ht0dSWD2Litwc=",
      "url": "_framework/Microsoft.JSInterop.g6svuh4n00.wasm"
    },
    {
      "hash": "sha256-II4qFjizmM7PBkinQnundzwFByRIRAbnjGAp2PkZCvg=",
      "url": "_framework/MudBlazor.gcqmj4g3kd.wasm"
    },
    {
      "hash": "sha256-RPAt85/I7YYmVrIkX2i5MEGgaLyjRdHR043i3PrEb4s=",
      "url": "_framework/MudBlazorGitHubPages.8vucxau362.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-2+Qj4wYEFirLYjCHxUJSxDTpPzCq6Z0gVmrMrcO7g9c=",
      "url": "_framework/Serilog.ti8gg3xy57.wasm"
    },
    {
      "hash": "sha256-9aaW4dF5NU1cIolqSR+7cejDqL6oUR60N+J+tJZeCmE=",
      "url": "_framework/System.Collections.Concurrent.lsb585e7yi.wasm"
    },
    {
      "hash": "sha256-S2QDnOtJFc6AvOb2bX3xVL/TBez7K+S+x/lD2mmq7e0=",
      "url": "_framework/System.Collections.Immutable.9n7kc7fx0a.wasm"
    },
    {
      "hash": "sha256-w1usuXKNK2j74xSspdrSCx4YAYIg/2gVNfLKMRO6vuA=",
      "url": "_framework/System.Collections.NonGeneric.1j1ioxl1mw.wasm"
    },
    {
      "hash": "sha256-pohqbPAu0xAXaNmmekPiHQXvKduBrP0K2hT/CgE3vos=",
      "url": "_framework/System.Collections.Specialized.2lvnxisy2k.wasm"
    },
    {
      "hash": "sha256-HtNn/u9+bBOZjkWf1Np4XxNJonk4gFSC0Nx/8OP2bCY=",
      "url": "_framework/System.Collections.iofu2clhlb.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-OEUiONvTvRl0zXaRpOxe8N1bZm9G8n1a8O1MU0CuiIs=",
      "url": "_framework/System.ComponentModel.Annotations.c3oteuai4j.wasm"
    },
    {
      "hash": "sha256-JqB9Chv9hcASUR19UbVo2L0+9ED/FhpGBdOZA/Y9+Es=",
      "url": "_framework/System.ComponentModel.Primitives.eee9rhpydd.wasm"
    },
    {
      "hash": "sha256-27z0qxbUA3HFjiqD7c5kmcBiDjoC76E6K+KtxLXNubs=",
      "url": "_framework/System.ComponentModel.TypeConverter.9b9steniom.wasm"
    },
    {
      "hash": "sha256-OLm71vFejrfS7tuHwbQIrbPJJFFvqFC1eM7SgYnxTfA=",
      "url": "_framework/System.Console.gi7zmwq5sa.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-T5aIvblpPkrCyPo6wW7xNx403EZ6q05eSBUN4aVeBbA=",
      "url": "_framework/System.Linq.Expressions.lzvj18kh7x.wasm"
    },
    {
      "hash": "sha256-r7ZblEyJpmhVS1rlCqVfM5wPDUjCE/EM2r/ptKxCNq0=",
      "url": "_framework/System.Linq.fcz3hgb9tm.wasm"
    },
    {
      "hash": "sha256-cogZ93o17jQq3v9gfbCiEi3NkOEbeJgaWUnNTLgMIfA=",
      "url": "_framework/System.Memory.6vh06ia9tj.wasm"
    },
    {
      "hash": "sha256-AUh9H4KMFMgWv0ROj41gfS07588GWmmrsXuyfoooljc=",
      "url": "_framework/System.Net.Http.xgu7qeey5v.wasm"
    },
    {
      "hash": "sha256-ATD97tYcgeYU6qhLjcFpeIbpkzSMNEqYgBaQAzNMgCQ=",
      "url": "_framework/System.Net.Primitives.xosvhvwc8p.wasm"
    },
    {
      "hash": "sha256-Plvspx59N0C/2+n8w2PHxa7F3W0cWjbzVdLpS4RHDbw=",
      "url": "_framework/System.ObjectModel.ikukleiakp.wasm"
    },
    {
      "hash": "sha256-rFRH7/O9soCWIoMMJTBBqTeLatRTS0HxO7utXhksang=",
      "url": "_framework/System.Private.CoreLib.w9nuebcpmu.wasm"
    },
    {
      "hash": "sha256-ucF5pux7ZKLwu/GVRWzNaY3XKqv37BxL79851HGFXfw=",
      "url": "_framework/System.Private.Uri.zpakb84iop.wasm"
    },
    {
      "hash": "sha256-5Gru8lhVTGY7XS1KKVRZjDFARt3p1nsfa1Tj2CPdRsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.cqbusmqy15.wasm"
    },
    {
      "hash": "sha256-UM9ZZQVffJA5LjI9zN4QgVJ/h/dyL7MOnnlMatfO3Ag=",
      "url": "_framework/System.Runtime.wkyxaq3ugt.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-fWtRfDVICwOnnn3BgrObNKO6Yj3N8D9bwIrtpriXYJU=",
      "url": "_framework/System.Text.Json.zo8isno3ro.wasm"
    },
    {
      "hash": "sha256-1KCXbQjy4gMzzFtDv9s6xyliBjvVIlb3dhR8OpegkOY=",
      "url": "_framework/System.Text.RegularExpressions.su8wwvjqyg.wasm"
    },
    {
      "hash": "sha256-8TOdx+WTSrBAkPVcYh/dHgxZeRNAfj3bK1p4ESYA1bo=",
      "url": "_framework/System.Threading.92ez24v1xd.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-kRogbelrKg/hR6Qjkd39hZqKFRMACT1GcSMvCumbNsc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Qm1PpBk7yGHo09sdI1I1AzWwM+roIu0WfZY719dDzvA=",
      "url": "_framework/dotnet.native.qtxmy7a3h7.wasm"
    },
    {
      "hash": "sha256-F/5e/lyR+oUxW0davFx8aANjOB+Ddu6RYx2NRUxshPw=",
      "url": "_framework/dotnet.native.vmus01doem.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LV3+f00+twyg9GdkcdZgHL9eNsYya/KVnqdVOAG71Os=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
